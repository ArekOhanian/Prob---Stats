package PokemonStadium;

public class charmander extends pokemon{
    //golbal variables
    

    public charmander(){
        setHp(39);
        setAtk(52);
        setDef(43);
        setSpd(65);
    }
}
