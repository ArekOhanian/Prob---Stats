package PokemonStadium;

public class pikachu extends pokemon{

    public pikachu(){
        setHp(35);
        setAtk(55);
        setDef(30);
        setSpd(90);
    }
}
