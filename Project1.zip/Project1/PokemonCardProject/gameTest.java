package PokemonCardProject;

public class gameTest {
    public static void main(String [] args){
        //Player p = new Player("a");
        //p.cardMulliganChance();
        //p.rareCandyPrizeChance();
        Game game = new Game();
        game.runGame();
    }
}
